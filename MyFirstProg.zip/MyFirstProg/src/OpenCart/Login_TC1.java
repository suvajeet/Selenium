package OpenCart;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import jxl.read.biff.BiffException;


public class Login_TC1 {

	public static void main(String[] args) throws BiffException, IOException {
		
		//Creating a ExcelParser object to call the ReadExcel() method for fetching the excel data through a string array
		ExcelParser objExcelParser=new ExcelParser();
		String[][] myArray=objExcelParser.ReadExcel();
		
		int rows=myArray.length;
		
			for(int row=0;row<rows;row++)
			{
					
				//Launching browser
				WebDriver objWebdrive=new ChromeDriver();
				System.setProperty("webdriver.chrome.driver","chromedriver.exe");
				objWebdrive.manage().window().maximize();
				
				//Navigating to Opencart app
				objWebdrive.get("http://10.207.182.108:81/opencart/");
				
				objWebdrive.findElement(By.xpath("//a[text()='login']")).click();
				
				objWebdrive.findElement(By.xpath("//input[@type='text' and @name='email']")).sendKeys(myArray[row][0]);
				objWebdrive.findElement(By.xpath("//input[@name='password']")).sendKeys(myArray[row][1]);
				//wait for one seconds
				try{Thread.sleep(1000);}
				catch(Exception e){}
				
				objWebdrive.findElement(By.xpath("//input[@value='Login']")).click();
				String user=objWebdrive.findElement(By.xpath("//div[@id='welcome']/a[@href='http://10.207.182.108:81/opencart/index.php?route=account/account']")).getText();
				if(user.equalsIgnoreCase(myArray[row][2]))
				{
					System.out.println("Iteration-"+(row+1)+" is Passed");
				}
				else{
					System.out.println("Iteration-"+(row+1)+" is Failed");
				}
				//wait for one seconds
				try{Thread.sleep(1000);}
				catch(Exception e){}
				
				objWebdrive.findElement(By.xpath("//div[@id='welcome']/a[text()='Logout']")).click();
				
				//wait for one seconds
				try{Thread.sleep(1000);}
				catch(Exception e){}
				//closing the browser
				objWebdrive.close();
				
			}
										
	}

}
