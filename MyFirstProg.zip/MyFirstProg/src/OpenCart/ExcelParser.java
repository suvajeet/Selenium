package OpenCart;

import java.io.File;
import java.io.IOException;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class ExcelParser {

	public String[][] ReadExcel() throws BiffException, IOException{
	
		//Reading data from excel file and storing it in local 2D array
		File myFile=new File("Data.xls");
		Workbook objWorkbook= Workbook.getWorkbook(myFile);
		Sheet objSheet=objWorkbook.getSheet(0);
		int cols=objSheet.getColumns();
		int rows=objSheet.getRows();
		
		String[][] myArray=new String[rows][cols];
		for(int row=0;row<rows;row++){
			for(int col=0;col<cols;col++){
				Cell objCell=objSheet.getCell(col,row);
				myArray[row][col]=objCell.getContents();
				//System.out.println(myArray[row][col]);
			}
		}
		return myArray;
	}
	
}
